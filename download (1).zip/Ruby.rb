#unless

#numero = 3

#isVerdadero = false

#puts "El número existe" if numero
#puts "El número no existe" unless numero
#puts "La variable es falsa o no existe" unless isVerdadero


#numero = 3
#puts "El número ahora si existe" if numero
#puts "-------------------"
#puts numero

=begin
name = gets.chomp
if name == "Daniel"
   puts "Hola Daniel"
end

if name != "Daniel"
  puts "Hola Visitante"
else 
  puts name + " es igual a Daniel"
end

puts "Escribe tu edad:"
numero = gets.chomp.to_i
if numero > 17
  puts "#{numero} es mayor que 17, eres mayor de edad"
elsif numero < 17
  puts "#{numero} es menos a 17, eres menor de edad"
else
  puts "#{numero} es igual a 17, so close"
end

if numero >= 35
  puts "#{numero} es mayor a 45, eres chavo-ruco"
end

isVerdadero = false

if(!isVerdadero) and (numero >= 17)
  puts "la variable es falsa y el número es mayor o igual a 17"
end


edad = gets.chomp.to_i
case edad
  when 0 .. 2
   puts "Bebe"
 when 3 .. 5
  puts "Niñito"
 when 7 .. 12
  puts "Niño"
 when 13 .. 18
  puts "Adolescente"
else
  puts "Adulto"
end

case edad 
  when 0 .. 2, 4 .. 100
    puts "el número está entre 0 y 2 o 4 y 100"
  when 3
    puts "el número es 3"
  else
    puts "el número es negativo o mayor a 100"
end
  

numero = 0
while numero < 5 do
  puts("el número es: #{numero}")
  numero = numero + 1
end

numero = 0
begin
  puts ("el número es: i = #{numero}")
  numero +=1
end while numero < 5

  numero = 0
while numero < 5
  puts ("el número es: i = #{numero}")
  numero +=1
end 
  
for i in 0..3
  puts "El valor de la variable es: #{i}"
end

 numero = 0
  until numero > 5 do
  puts ("el número es: i = #{numero}")
  numero +=1
end 

names = ['Ada', 'Belle', 'Chris']
puts names
puts names[0]
puts names[1]
puts names[2]

manu = ['los aviones ', 'viajar ', 'la mañana ', 'el viento ', 'soñar ', 'la mar ']
manu.each do |letra|
  puts '¡Me gusta ' + letra + '¡Me gustas tú !'
end
chao = ['Je ne sais pas ', 'Je ne sais plus ']
chao.each do |coro|
  puts '¿Qué voy a hacer? ' + coro + '!'
end
2.times do
  puts '¿Qué hora son mi corazón? '
end


favoritos = []
favoritos.push 'Elemento 1'
favoritos.push 'Elemento 2'

puts favoritos.pop
puts favoritos 
puts favoritos.length

lenguajes = ['ingles', 'frances', 'java', 'aleman', 'c']
puts lenguajes
puts
puts lenguajes.to_s
puts 
lenguajes2 = lenguajes.join(', ')
puts lenguajes2
puts lenguajes.join(' XD ') + 'EOL '

def Saludar numeroSaludos
  puts 'Hola, Hello, Hallo, Salut, Ciao' * numeroSaludos
end

Saludar 5
#duplica
def duplica num
  numero = num * 2
  puts "#{num} el doble es #{numero}"
  puts num.to_s + 'el doble es' + numero.to_s
end

duplica 30

puts numero



class Vehiculo
  def initialize (modelo, marca, precio)
    @modelo = modelo
    @marca = marca
    @precio = precio
  end
  
  def modelo
    @modelo
  end
  #attr_reader :modelo, :marca, :precio
  #attr_writer :modelo, :marca, :precio
  attr_accesor :modelo, :marca, :precio
  def marca
    @marca
  end
  
  def precio
    @precio
  end
  
  def encender
    puts "Encender vehiculo"
  end
  
  def apagar
    puts "Apagar coche"
  end
  
  def acelerar
    puts "Acelerar vehiculo"
  end
  
  def frenar
    puts "Frenar vehiculo"
  end
 
end

class Bicicleta < Vehiculo
  def pedalear
    puts "Aquí pedaleando la bicicleta del vecino"
  end
  
  def despegar
    puts "#{@marca}, #{@modelo} no puede despegar"
  end
end

auto = vehiculo.new('2016', 'Nissan', 233000.00)
#auto.methods.sort

auto.encender
auto.acelerar
auto.frenar
auto.apagar

if auto.respond_to?("volar")
  auto.volar
else
  puts "Lo siento, el objeto no entiende el mensaje apagar"
end

if auto.respond_to?("apagar")
  auto.apagar
end

d1 = auto
d1.encender
auto = nil
d1.apagar

 vehiculo = vehiculo.new("2016", "Chevy", 64563543)
  vehiculo.modelo
  vehiculo.marca
  vehiculo.precio

trek = Bicicleta.new("2015", "Dura Dura", 65556)

if trek.respond_to?("despegar")
  trek.despegar
else
  puts "No se puede despegar, joven"
end

class Bike
  attr_reader :velocidades, :ruedas, :asientos
  def initialize(*arg)
    @ruedas = arg[0]
    @asientos = arg[1]
    @velocidades = arg[2]
  end
end

    
class Tandem < Bike
  attr_reader : canastilla
  
  def initialize(asientos, ruedas, velocidades)
    super
    @asientos = asientos
    @ruedas = ruedas
    @velocidades = velocidades
  end
  
  
  class Animal
    def sonido
      p "ladrar"
    end
  end
  animal = animal.new
  animal.sonido
  
  Animal.new.sonido
  
  class Perro
    def sonido
      puts "Ladra"
    end
  end
  
Class Buho 
  def sonido
    puts "Ulula"
  end
end

Class Cabra
  def sonido
    puts "Bala"
  end
end


Class Persona
  def initialize(nombre, edad)
    @nombre = nombre
    @edad = edad
  end

 def edad
   @edad
 end

  def nombre
    @nombre
  end

  def edad = (edad)
    @edad = edad
  end

  def nombre =   (nombre)
    @nombre = nombre
  end

  def saludar
    puts "Hola"
  end
end

persona = Persona.new("Mariano", 20)
p persona.nombre
p persona.edad
p persona.nombre = "David"
p persona.edad = 16
persona.saludar
end
puts "Ingrese el total de elementos:"
eTotal = gets.chomp.to_i
aExpresion = []
eCont = 0
for eCont in 0..eTotal
  puts "Ingrese el elemento de " + eCont + ":"
  sTemp = gets.chomp
  aExpresion.push sTemp
end
=end

puts "Ingrese a:"
a = gets.chomp.to_i
puts "Ingrese b:"
b = gets.chomp.to_i
puts "Ingrese c:"
c = gets.chomp.to_i
puts "Ingrese d:"
d = gets.chomp.to_i
producto = a * b * c * d
suma = a + b + c + d
media = suma/4
puts "El producto es:" + producto
puts "La suma es:" + suma
puts "La media es: " + media

puts "Ingrese base:"
base = gets.chomp.to_f
puts "Ingrese altura:"
altura = gets.chomp.to_f
area = base / altura
puts "El area es de:" + area

puts "Ingrese un numero:"
n = gets.chomp.to_i
residuo = n % 2
if residuo == 0
  puts "Si es par"
else
  puts "No es par"
end

puts "Introduzca el primer numero:"
a = gets.chomp.to_i
puts "Introduzca el segundo numero:"
b = gets.chomp.to_i
c = a + b
puts "La suma es:" + c
