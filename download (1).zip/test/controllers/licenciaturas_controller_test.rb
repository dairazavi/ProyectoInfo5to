require 'test_helper'

class LicenciaturasControllerTest < ActionController::TestCase
  setup do
    @licenciatura = licenciaturas(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:licenciaturas)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create licenciatura" do
    assert_difference('Licenciatura.count') do
      post :create, licenciatura: { clave: @licenciatura.clave, nombre: @licenciatura.nombre }
    end

    assert_redirected_to licenciatura_path(assigns(:licenciatura))
  end

  test "should show licenciatura" do
    get :show, id: @licenciatura
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @licenciatura
    assert_response :success
  end

  test "should update licenciatura" do
    patch :update, id: @licenciatura, licenciatura: { clave: @licenciatura.clave, nombre: @licenciatura.nombre }
    assert_redirected_to licenciatura_path(assigns(:licenciatura))
  end

  test "should destroy licenciatura" do
    assert_difference('Licenciatura.count', -1) do
      delete :destroy, id: @licenciatura
    end

    assert_redirected_to licenciaturas_path
  end
end
