require 'test_helper'

class EscritorsControllerTest < ActionController::TestCase
  setup do
    @escritor = escritors(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:escritors)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create escritor" do
    assert_difference('Escritor.count') do
      post :create, escritor: { apeMat: @escritor.apeMat, apePat: @escritor.apePat, fecNac: @escritor.fecNac, nombre: @escritor.nombre }
    end

    assert_redirected_to escritor_path(assigns(:escritor))
  end

  test "should show escritor" do
    get :show, id: @escritor
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @escritor
    assert_response :success
  end

  test "should update escritor" do
    patch :update, id: @escritor, escritor: { apeMat: @escritor.apeMat, apePat: @escritor.apePat, fecNac: @escritor.fecNac, nombre: @escritor.nombre }
    assert_redirected_to escritor_path(assigns(:escritor))
  end

  test "should destroy escritor" do
    assert_difference('Escritor.count', -1) do
      delete :destroy, id: @escritor
    end

    assert_redirected_to escritors_path
  end
end
