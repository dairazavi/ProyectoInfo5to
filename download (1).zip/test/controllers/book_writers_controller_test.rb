require 'test_helper'

class BookWritersControllerTest < ActionController::TestCase
  setup do
    @book_writer = book_writers(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:book_writers)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create book_writer" do
    assert_difference('BookWriter.count') do
      post :create, book_writer: { book_id: @book_writer.book_id, writer_id: @book_writer.writer_id }
    end

    assert_redirected_to book_writer_path(assigns(:book_writer))
  end

  test "should show book_writer" do
    get :show, id: @book_writer
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @book_writer
    assert_response :success
  end

  test "should update book_writer" do
    patch :update, id: @book_writer, book_writer: { book_id: @book_writer.book_id, writer_id: @book_writer.writer_id }
    assert_redirected_to book_writer_path(assigns(:book_writer))
  end

  test "should destroy book_writer" do
    assert_difference('BookWriter.count', -1) do
      delete :destroy, id: @book_writer
    end

    assert_redirected_to book_writers_path
  end
end
