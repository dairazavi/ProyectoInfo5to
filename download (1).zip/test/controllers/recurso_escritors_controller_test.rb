require 'test_helper'

class RecursoEscritorsControllerTest < ActionController::TestCase
  setup do
    @recurso_escritor = recurso_escritors(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:recurso_escritors)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create recurso_escritor" do
    assert_difference('RecursoEscritor.count') do
      post :create, recurso_escritor: { escritor_id: @recurso_escritor.escritor_id, recurso_id: @recurso_escritor.recurso_id }
    end

    assert_redirected_to recurso_escritor_path(assigns(:recurso_escritor))
  end

  test "should show recurso_escritor" do
    get :show, id: @recurso_escritor
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @recurso_escritor
    assert_response :success
  end

  test "should update recurso_escritor" do
    patch :update, id: @recurso_escritor, recurso_escritor: { escritor_id: @recurso_escritor.escritor_id, recurso_id: @recurso_escritor.recurso_id }
    assert_redirected_to recurso_escritor_path(assigns(:recurso_escritor))
  end

  test "should destroy recurso_escritor" do
    assert_difference('RecursoEscritor.count', -1) do
      delete :destroy, id: @recurso_escritor
    end

    assert_redirected_to recurso_escritors_path
  end
end
