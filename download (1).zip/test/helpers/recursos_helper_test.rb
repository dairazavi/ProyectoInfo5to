require 'test_helper'

class RecursosHelperTest < ActionView::TestCase
end
