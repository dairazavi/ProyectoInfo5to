require 'test_helper'

class LicenciaturasHelperTest < ActionView::TestCase
end
