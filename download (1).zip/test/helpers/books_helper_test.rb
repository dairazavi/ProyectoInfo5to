require 'test_helper'

class BooksHelperTest < ActionView::TestCase
end
