require 'test_helper'

class EditorialsHelperTest < ActionView::TestCase
end
