require 'test_helper'

class ProfesorsHelperTest < ActionView::TestCase
end
