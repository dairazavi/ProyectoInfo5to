require 'test_helper'

class EscritorsHelperTest < ActionView::TestCase
end
