require 'test_helper'

class VentaHelperTest < ActionView::TestCase
end
