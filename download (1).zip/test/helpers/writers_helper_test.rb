require 'test_helper'

class WritersHelperTest < ActionView::TestCase
end
