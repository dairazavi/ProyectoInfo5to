require 'test_helper'

class PersonasHelperTest < ActionView::TestCase
end
