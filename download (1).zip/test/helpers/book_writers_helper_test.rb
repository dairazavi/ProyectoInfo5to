require 'test_helper'

class BookWritersHelperTest < ActionView::TestCase
end
