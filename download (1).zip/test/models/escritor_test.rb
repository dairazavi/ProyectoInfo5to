require 'test_helper'

class EscritorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
