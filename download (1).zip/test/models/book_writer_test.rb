require 'test_helper'

class BookWriterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
