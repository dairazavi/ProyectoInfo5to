require 'test_helper'

class EditorialTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
