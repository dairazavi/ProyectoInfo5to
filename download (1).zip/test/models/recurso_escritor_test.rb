require 'test_helper'

class RecursoEscritorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
