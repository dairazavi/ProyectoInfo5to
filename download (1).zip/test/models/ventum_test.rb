require 'test_helper'

class VentumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
