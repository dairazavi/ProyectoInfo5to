require 'test_helper'

class ProfesorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
