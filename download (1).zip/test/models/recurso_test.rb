require 'test_helper'

class RecursoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
