class Book < ActiveRecord::Base
  has_many :bookwriter
  has_many :writers, through: :bookwriter
  validates :name, presence: true
  validates :stock, numericality: { only_integer: true }
end
