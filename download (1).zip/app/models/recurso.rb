class Recurso < ActiveRecord::Base
  has_many :recursoescritor
  has_many :ventas
  has_many :users, through: :venta 
  has_many :escritores, through: :recursoescritor
  belongs_to :editorial
  validates :titulo, presence: true
  #validates :tipo, presence: true
  #validates :stock, numericality: { only_integer: true }
  validates_numericality_of :stock, :greater_than_or_equal_to => 0
end
