class Licenciatura < ActiveRecord::Base
end
