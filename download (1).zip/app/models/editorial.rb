class Editorial < ActiveRecord::Base
  has_many :recursos
end
