class Profesor < ActiveRecord::Base
end
