class BookWriter < ActiveRecord::Base
  belongs_to :book
  belongs_to :writer
  validates :book, uniqueness: { scope: :writer, message: "El libro con el autor seleccionado ya está registrado" }
end
