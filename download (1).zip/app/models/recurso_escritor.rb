class RecursoEscritor < ActiveRecord::Base
  belongs_to :recurso
  belongs_to :escritor
  validates :recurso, uniqueness: { scope: :escritor, message: "El libro con el escritor  seleccionado ya está registrado." }
end
