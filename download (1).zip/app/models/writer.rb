class Writer < ActiveRecord::Base
  has_many :bookwriter
  has_many :books, through: :bookwriter
  validates :name, presence: { message: "Es necesario un autor para continuar" }
end
