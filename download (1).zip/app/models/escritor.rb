class Escritor < ActiveRecord::Base
  has_many :recursoescritor
  has_many :recursos, through: :recursoescritor
  validates :nombre, presence: { message: "Es necesario un escritor para continuar" } 
end
