class Ventum < ActiveRecord::Base
 after_save :descontar_stock
  
   belongs_to :recurso
   belongs_to :user
   validates :cantidad, presence: true
  
 private
  
  def descontar_stock
    self.recurso.stock -= self.cantidad
    self.recurso.save
  end
  

end
