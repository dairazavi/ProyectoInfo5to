class BookWritersController < ApplicationController
  before_action :set_book_writer, only: [:show, :edit, :update, :destroy]

  respond_to :html

  def index
    @book_writers = BookWriter.all
    respond_with(@book_writers)
  end

  def show
    respond_with(@book_writer)
  end

  def new
    @book_writer = BookWriter.new
    respond_with(@book_writer)
  end

  def edit
  end

  def create
    @book_writer = BookWriter.new(book_writer_params)
    @book_writer.save
    respond_with(@book_writer)
  end

  def update
    @book_writer.update(book_writer_params)
    respond_with(@book_writer)
  end

  def destroy
    @book_writer.destroy
    respond_with(@book_writer)
  end

  private
    def set_book_writer
      @book_writer = BookWriter.find(params[:id])
    end

    def book_writer_params
      params.require(:book_writer).permit(:book_id, :writer_id)
    end
end
