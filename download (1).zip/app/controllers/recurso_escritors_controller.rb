class RecursoEscritorsController < ApplicationController
  before_action :set_recurso_escritor, only: [:show, :edit, :update, :destroy]

  respond_to :html

  def index
    @recurso_escritors = RecursoEscritor.all
    respond_with(@recurso_escritors)
  end

  def show
    respond_with(@recurso_escritor)
  end

  def new
    @recurso_escritor = RecursoEscritor.new
    respond_with(@recurso_escritor)
  end

  def edit
  end

  def create
    @recurso_escritor = RecursoEscritor.new(recurso_escritor_params)
    @recurso_escritor.save
    respond_with(@recurso_escritor)
  end

  def update
    @recurso_escritor.update(recurso_escritor_params)
    respond_with(@recurso_escritor)
  end

  def destroy
    @recurso_escritor.destroy
    respond_with(@recurso_escritor)
  end

  private
    def set_recurso_escritor
      @recurso_escritor = RecursoEscritor.find(params[:id])
    end

    def recurso_escritor_params
      params.require(:recurso_escritor).permit(:escritor_id, :recurso_id)
    end
   
end
