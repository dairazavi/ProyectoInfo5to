class LicenciaturasController < ApplicationController
  before_action :authenticate_user!
  before_action :set_licenciatura, only: [:show, :edit, :update, :destroy]

  # GET /licenciaturas
  # GET /licenciaturas.json
  def index
    @licenciaturas = Licenciatura.all
  end

  # GET /licenciaturas/1
  # GET /licenciaturas/1.json
  def show
  end

  # GET /licenciaturas/new
  def new
    @licenciatura = Licenciatura.new
  end

  # GET /licenciaturas/1/edit
  def edit
  end

  # POST /licenciaturas
  # POST /licenciaturas.json
  def create
    @licenciatura = Licenciatura.new(licenciatura_params)

    respond_to do |format|
      if @licenciatura.save
        format.html { redirect_to @licenciatura, notice: 'Licenciatura was successfully created.' }
        format.json { render :show, status: :created, location: @licenciatura }
      else
        format.html { render :new }
        format.json { render json: @licenciatura.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /licenciaturas/1
  # PATCH/PUT /licenciaturas/1.json
  def update
    respond_to do |format|
      if @licenciatura.update(licenciatura_params)
        format.html { redirect_to @licenciatura, notice: 'Licenciatura was successfully updated.' }
        format.json { render :show, status: :ok, location: @licenciatura }
      else
        format.html { render :edit }
        format.json { render json: @licenciatura.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /licenciaturas/1
  # DELETE /licenciaturas/1.json
  def destroy
    @licenciatura.destroy
    respond_to do |format|
      format.html { redirect_to licenciaturas_url, notice: 'Licenciatura was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_licenciatura
      @licenciatura = Licenciatura.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def licenciatura_params
      params.require(:licenciatura).permit(:nombre, :clave)
    end
end
