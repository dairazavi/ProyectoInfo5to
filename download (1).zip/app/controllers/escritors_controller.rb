class EscritorsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_escritor, only: [:show, :edit, :update, :destroy]

  respond_to :html

  def index
    @escritors = Escritor.all
    respond_with(@escritors)
  end

  def show
    respond_with(@escritor)
  end

  def new
    @escritor = Escritor.new
    respond_with(@escritor)
  end

  def edit
  end

  def create
    @escritor = Escritor.new(escritor_params)
    @escritor.save
    respond_with(@escritor)
  end

  def update
    @escritor.update(escritor_params)
    respond_with(@escritor)
  end

  def destroy
    @escritor.destroy
    respond_with(@escritor)
  end

  private
    def set_escritor
      @escritor = Escritor.find(params[:id])
    end

    def escritor_params
      params.require(:escritor).permit(:nombre, :apePat, :apeMat, :fecNac)
    end
end
