class WritersController < ApplicationController
  before_action :set_writer, only: [:show, :edit, :update, :destroy]

  respond_to :html

  def index
    @writers = Writer.all
    respond_with(@writers)
  end

  def show
    respond_with(@writer)
  end

  def new
    @writer = Writer.new
    respond_with(@writer)
  end

  def edit
  end

  def create
    @writer = Writer.new(writer_params)
    @writer.save
    respond_with(@writer)
  end

  def update
    @writer.update(writer_params)
    respond_with(@writer)
  end

  def destroy
    @writer.destroy
    respond_with(@writer)
  end

  private
    def set_writer
      @writer = Writer.find(params[:id])
    end

    def writer_params
      params.require(:writer).permit(:name, :country)
    end
end
