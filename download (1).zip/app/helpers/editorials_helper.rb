module EditorialsHelper
end
