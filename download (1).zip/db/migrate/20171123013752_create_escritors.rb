class CreateEscritors < ActiveRecord::Migration
  def change
    create_table :escritors do |t|
      t.string :nombre
      t.string :apePat
      t.string :apeMat
      t.date :fecNac

      t.timestamps
    end
  end
end
