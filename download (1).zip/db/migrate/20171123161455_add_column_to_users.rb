class AddColumnToUsers < ActiveRecord::Migration

  def change
      add_column :users, :nombre, :string, default: "Margarita"
    add_column :users, :apePat, :string, default: "Flores"
    add_column :users, :apeMat, :string, default: "Rosales"

  end
end
