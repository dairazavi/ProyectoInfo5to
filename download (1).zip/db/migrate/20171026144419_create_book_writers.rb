class CreateBookWriters < ActiveRecord::Migration
  def change
    create_table :book_writers do |t|
      
     t.belongs_to:writer, index: true
     t.belongs_to:book, index: true
      
      t.timestamps
    end
    add_index :book_writers, [:writer_id, :book_id], :unique => true
  end
end
