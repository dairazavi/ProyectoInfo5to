class CreateAuthors < ActiveRecord::Migration
  def change
    drop_table :authors
    create_table :authors do |t|
      t.string :name

      t.timestamps
    end
  end
end
