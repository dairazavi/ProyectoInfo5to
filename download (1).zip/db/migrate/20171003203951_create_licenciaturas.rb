class CreateLicenciaturas < ActiveRecord::Migration
  def change
    create_table :licenciaturas do |t|
      t.string :nombre
      t.integer :clave

      t.timestamps
    end
  end
end
