class CreateRecursos < ActiveRecord::Migration
  def change
    create_table :recursos do |t|
      t.string :titulo
      t.integer :stock
      t.string :descripcion
      t.float :costo
      t.float :precio
      t.string :tipo
      t.belongs_to :editorial, index: true
      t.timestamps
    end
  end
end
