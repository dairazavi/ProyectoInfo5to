class AddRoleToUsers < ActiveRecord::Migration
  def change
    add_column :users, :role, :string, default: "vendedor"
    add_column :users, :nombre, :string, default: "Margarita"
    add_column :users, :apePat, :string, default: "Flores"
    add_column :users, :apeMat, :string, default: "Rosales"
    add_column :users, :fecContratacion, :date, default: CURRENT_TIMESTAMP
  end
end