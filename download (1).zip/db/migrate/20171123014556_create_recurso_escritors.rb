class CreateRecursoEscritors < ActiveRecord::Migration
  def change
    create_table :recurso_escritors do |t|
      t.belongs_to:escritor, index: true
      t.belongs_to:recurso, index: true

      t.timestamps
    end
    add_index :recurso_escritors, [:escritor_id, :recurso_id], :unique => true
  end
end
