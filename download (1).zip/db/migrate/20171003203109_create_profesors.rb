class CreateProfesors < ActiveRecord::Migration
  def change
    create_table :profesors do |t|
      t.string :carrera
      t.integer :experiencia
      t.integer :sueldo

      t.timestamps
    end
  end
end
