class CreatePersonas < ActiveRecord::Migration
  def change
    create_table :personas do |t|
      t.string :nombre
      t.string :apellidoPaterno
      t.string :apellidoMaterno

      t.timestamps
    end
  end
end
