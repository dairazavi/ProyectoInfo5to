class CreateVenta < ActiveRecord::Migration
  def change
    drop_table :venta
    create_table :venta do |t|
      t.belongs_to :user, index: true
      t.belongs_to :recurso, index: true
      t.integer :cantidad
      t.date :fecha

      t.timestamps
    end
  end
end
